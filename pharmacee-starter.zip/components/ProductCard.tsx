type ProductCardProps = {
  product: {
    id: number
    name: string
    description: string
    price: number
  }
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="border p-4 rounded shadow">
      <h2 className="text-xl font-semibold">{product.name}</h2>
      <p className="text-gray-600">{product.description}</p>
      <p className="font-bold">${product.price.toFixed(2)}</p>
    </div>
  )
}