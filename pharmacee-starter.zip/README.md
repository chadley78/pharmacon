# Pharmacee – Ecommerce Starter

This is a starter ecommerce web app built with:

- Next.js
- Tailwind CSS
- Prisma + PostgreSQL
- Stripe

## Setup

1. Copy `.env.example` to `.env` and update your database + Stripe keys.
2. Install dependencies:

```bash
npm install
```

3. Run the Prisma migration:

```bash
npx prisma migrate dev --name init
```

4. Start the development server:

```bash
npm run dev
```